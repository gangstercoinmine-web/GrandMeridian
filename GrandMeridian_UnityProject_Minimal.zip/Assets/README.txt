Minimal Unity project for Cloud Build. Replace with real Assets folder if needed.
Place scenes in Assets/Scenes and scripts in Assets/Scripts.
